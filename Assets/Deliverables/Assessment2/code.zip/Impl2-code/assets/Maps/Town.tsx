<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Town" tilewidth="24" tileheight="24" tilecount="42" columns="7">
 <image source="../free version.png" width="176" height="144"/>
</tileset>
