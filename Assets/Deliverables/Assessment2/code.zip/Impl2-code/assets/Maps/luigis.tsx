<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="luigis" tilewidth="24" tileheight="24" tilecount="12" columns="3">
 <image source="../luigis.png" width="80" height="112"/>
</tileset>
