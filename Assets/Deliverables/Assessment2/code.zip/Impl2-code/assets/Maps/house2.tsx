<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="house2" tilewidth="24" tileheight="24" tilecount="20" columns="5">
 <image source="../TILESET-VILLAGE-TOP-DOWN/TILESET VILLAGE TOP DOWN/HOUSE 2 - DAY.png" width="128" height="112"/>
</tileset>
