<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bus" tilewidth="24" tileheight="24" tilecount="16" columns="4">
 <image source="Textures/bus.png" width="106" height="106"/>
</tileset>
