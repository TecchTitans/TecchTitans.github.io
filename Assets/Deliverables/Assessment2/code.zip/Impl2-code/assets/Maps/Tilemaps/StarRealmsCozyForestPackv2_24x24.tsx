<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="StarRealmsCozyForestPackv2_24x24" tilewidth="24" tileheight="24" tilecount="528" columns="22">
 <image source="../../StarRealmsCozyForestPackv2_24x24.png" width="550" height="576"/>
</tileset>
