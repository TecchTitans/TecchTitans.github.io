<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TX Props" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="../Textures/TX Props.png" width="512" height="512"/>
</tileset>
