<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="piazza" tilewidth="24" tileheight="24" tilecount="216" columns="18">
 <image source="../Textures/piazza.png" width="432" height="288"/>
</tileset>
